import logging

__version__ = '2.3.1'
logging.basicConfig(format='%(asctime)s %(message)s')
