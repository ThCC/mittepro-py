# coding=utf-8

variables = {
    "recipients": [
        "Thíàgõ <thiago.decastro2@gmail.com>",
        "Läçêrdà <thiago.dsn.cir@alterdata.com.br>"
    ],
    "context_per_recipient": {
        "thiago.decastro2@gmail.com": {
            "updateprofile": "https://www.google.com/doodles/celebrating-ruth-asawa",
            "update_profile": "https://www.google.com/doodles/teachers-day-2019-paraguay",
            "sobrenome": "Tíâò",
            "lastname": "Làçẽrdä",
            "forward": "https://www.google.com/doodles/celebrating-the-new-era",
            "resub": "https://www.google.com/doodles/na-hye-soks-123rd-birthday",
            "unsub": "https://www.google.com/doodles/rosy-afsaris-73rd-birthday",
            "aniversario": "17/11",
            "birthday": "12/01",
            "e-mail": "thiago.dsn.cir@alterdata.com.br",
            "email": "alex.dsn.cir@alterdata.com.br",
            "nome": "Àléx",
            "name": "Ãlëx",
        },
        "thiago.dsn.cir@alterdata.com.br": {
            "updateprofile": "https://www.google.com/doodles/celebrating-ruth-asawa",
            "update_profile": "https://www.google.com/doodles/teachers-day-2019-paraguay",
            "sobrenome": "Tíâò",
            "lastname": "Làçẽrdä",
            "forward": "https://www.google.com/doodles/celebrating-the-new-era",
            "resub": "https://www.google.com/doodles/na-hye-soks-123rd-birthday",
            "unsub": "https://www.google.com/doodles/rosy-afsaris-73rd-birthday",
            "aniversario": "17/11",
            "birthday": "12/01",
            "e-mail": "thiago.dsn.cir@alterdata.com.br",
            "email": "alex.dsn.cir@alterdata.com.br",
            "nome": "Àléx",
            "name": "Ãlëx",
        }
    },
    "from_": 'Beutrano <beutrano@alterdata.com.br>',
    "from_2": '<beutrano@mail.com>',
    "template_slug": 'test-101',
    "message_text": "Using this message instead.",
    "message_html": "<em>Using this message <strong>instead</strong>.</em>",
    "key": '1e4be7cdd03545958e34',
    "secret": 'cf8cdba282104ed88f0a'
}
server_uri_test = 'http://172.16.72.93:8002'

search_variables = {
    'app_ids': '1001',
    'status': ['1', '2'],
    'start': '2019-05-01',
    'end': '2019-05-03',
    'name_sender': 'Beutrano',
    'email_sender': 'beutrano@alterdata.com.br',
    'name_receiver': 'Läçêrdà',
    'email_receiver': 'thiago.dsn.cir@alterdata.com.br',
    'template_slug': 'tpl-teste',
    'uuids': [
        '21da05e09a214bf',
        '7b9332128a3f461',
        '09f7ceac90fe4b3',
        '0f39a611031c4ff',
        'f2412b7062814de'
    ]
}
