import logging

__version__ = '2.4.1'
logging.basicConfig(format='%(asctime)s %(message)s')
