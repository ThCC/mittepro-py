variables = {
    "recipients": [
        "<thiago.decastro2@gmail.com>"
    ],
    'context': {'GMERGE': 'Mah oia Soh'},
    'context_per_recipient': {
        'thiago.decastro2@gmail.com': {'MERGE': 'Malandro salafrario'},
    },
    "from_": 'Beutrano <thiago.dsn.cir@alterdata.com.br>',
    'template_slug': 'tpl-teste',
    "message_text": "Using this message instead.",
    "message_html": "<em>Using this message <strong>instead</strong>.</em>",
    "key": '1e4be7cdd03545958e34',
    "secret": 'cf8cdba282104ed88f0a',
    "files_names": [
        # 'foo.pdf',
        # 'bar.jpg',
        # 'foo_bar.txt',
    ]
}