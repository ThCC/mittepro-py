import logging

__version__ = '2.4.0'
logging.basicConfig(format='%(asctime)s %(message)s')
